/**
 * Created by user on 2/6/2017.
		 */
public class tester
{
  public static dbConnect dbtest = new dbConnect();
  public static void main (String args[])
  {
    dbtest.createTable("Sy2017_18_1stsem");
  }
}
